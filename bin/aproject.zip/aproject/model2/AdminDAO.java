package aproject.model2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.jdbc.CallableStatement;
import com.shinhan.dbutil.OracleUtil;
import com.shinhan.dbutil.OracleUtil2;

import aproject.vo2.AdminVO;
import aproject.vo2.ProVO;

//DAO(Data Access Object):DB업무 ..CRUD..Insert,Select,Update,Delete 
public class AdminDAO {
	Connection conn;
	Statement st;
	PreparedStatement pst;// ?지원
	java.sql.CallableStatement cst;//SP지원
	ResultSet rs;
	int resultCount;// insert, update, delete건수
	
	//login
	public AdminVO getlogin(int adminid, String adminPwd) {
		
		AdminVO adm = null;
		
		String sql = "select * from admin where id = " + adminid +" and password = '"+ adminPwd+"'"  ;
		conn = OracleUtil2.getConnection();
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				adm = makeAdm(rs);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			OracleUtil2.dbDisconnect(rs, st, conn);
		}
		return adm;
	}
	
	//상품조회
	public List<ProVO> selectAll() {
		String sql = "select * from product ";
		List<ProVO> prolist = new ArrayList<>();
		conn = OracleUtil2.getConnection();
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				ProVO pro = makepro(rs);
				prolist.add(pro);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			OracleUtil2.dbDisconnect(rs, st, conn);
		}
		return prolist;
	}
	
	//로그인
	private AdminVO makeAdm(ResultSet rs) throws SQLException {
		AdminVO adm = new AdminVO();
		adm.setId(rs.getInt("id"));
		adm.setPassword(rs.getString("password"));
		adm.setHire_date(rs.getDate("hiredate"));
		adm.setPhone_number(rs.getString("Phonenumber"));

		return adm;
	}
	//입고등록
	public int proInsert(ProVO pro) {
		String sql = """
				insert into product
				values(seq_product.nextval,?,?,?)
				""";
		conn = OracleUtil2.getConnection();
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, pro.getP_code() );
			pst.setInt(2, pro.getPrice() );
			pst.setInt(3, pro.getNum() );
			
			resultCount = pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			 OracleUtil.dbDisconnect(null, pst, conn);
		}
		return resultCount;
	}
	
	
	
	private ProVO makepro(ResultSet rs) throws SQLException {
		ProVO pro = new ProVO();
		pro.setP_code(rs.getString("P_code"));
		pro.setPrice(rs.getInt("Price"));
		pro.setNum(rs.getInt("Num"));

		return pro;
	}
	
}