package aproject.model2;

import java.util.List;

import aproject.vo2.AdminVO;
import aproject.vo2.ProVO;



//Service : 업무로직 담당 
public class AdminService {

	AdminDAO admDao = new AdminDAO();
	
	//login
	public AdminVO getlogin(int adminid, String adminPwd) {
		return admDao.getlogin(adminid, adminPwd);
	}
	//상품조회
	public List<ProVO> selectAll() {
		return admDao.selectAll();
	}
	
	//입고등록
	public String proInsert(ProVO pro) {
		int result = admDao.proInsert (pro);
		return result>0?"입력성공":"입력실패";
	}
}
