package aproject.view2;

import java.util.List;

import aproject.vo2.AdminVO;
import aproject.vo2.ProVO;

public class AdminView {
	
	public static void print(String message) {
			System.out.println("[알림]" + message);
	}

	public static AdminVO print(AdminVO getlogin) {
		System.out.println("================로그인되었습니다.=============");
		return getlogin;
		
	}
	
	public static void print(List<ProVO> prolist) {
		System.out.println("================상품정보=============");
		for(ProVO pro:prolist) {
			System.out.println(pro);
		}
	}

}
